﻿namespace FileBrowserApp.Models
{
    public class FilesFolderModel
    {
        public string ParentFolder { get; set; }

        public string[] Folders { get; set; }

        public string[] Files { get; set; }


    }
}
