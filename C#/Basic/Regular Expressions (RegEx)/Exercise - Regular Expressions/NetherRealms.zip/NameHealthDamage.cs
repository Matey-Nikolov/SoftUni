﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nether_Realms_Regex
{
    class NameHealthDamage
    {
        public string Name { get; set; }

        public int Health { get; set; }

        public double Damage { get; set; }
    }
}
