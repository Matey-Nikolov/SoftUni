﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Exercise_Regular_Expressions
{
    class Program
    {
        static void Main()
        {
            List<Furniture> valid = new List<Furniture>();
            Match match;

            Regex regex = new Regex(@"^>>([?<name>A-Z{0,}a-z]+)+<<(?<price>\d+\.?\d+)+!([?<quant>\d+]+)\b");

            //  Regex regex = new Regex(@">>(?<name>[A-Za-z]+)<<(?<price>\d+.\d+)!(?<quant>\d+)");

            string input = Console.ReadLine();

            while (input != "Purchase")
            {
                match = regex.Match(input);

                if (match.Success)
                {

                    string name = match.Groups[1].Value;
                    decimal price = decimal.Parse(match.Groups[2].Value);
                    decimal quantity = decimal.Parse(match.Groups[3].Value);

                    valid.Add(new Furniture()
                    {
                        Name = name,
                        Price = price,
                        Quantity = quantity,
                    });
                }
                input = Console.ReadLine();
            }

            Console.WriteLine("Bought furniture:");
            decimal total = 0;

            foreach (var furniture in valid)
            {
                total += furniture.Price * furniture.Quantity;
                Console.WriteLine($"{furniture.Name}");
            }
            Console.WriteLine($"Total money spend: {total}");
        }
    }
}
