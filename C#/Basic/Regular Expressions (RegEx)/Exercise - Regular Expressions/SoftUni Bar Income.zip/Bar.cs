﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUni_Bar_Income_Regex
{
    class Bar
    {
        public Bar(string customer, string product, int count, decimal price)
        {
            this.Customer = customer;
            this.Product = product;
            this.Count = count;
            this.Price = price;
        }


        public string Customer { get; set; }
        public string Product { get; set; }
        public int Count { get; set; }
        public decimal Price { get; set; }
    }
}
