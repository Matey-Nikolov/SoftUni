﻿namespace SoftUni_Bar_Income_Regex
{
    using System;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;

    class Program
    {
        static void Main()
        {
            Regex regex = new Regex(@"%([A-Z][a-z]+)%[^\|$%\.0-9]*<([A-Z][a-z]+)>[^\|$%\.0-9]*\|(\d+)\|[^\|$%\.0-9]*(\d+\.?\d*)\$");
            List<Bar> income = new List<Bar>();
            Match match;

            string customerProductCountPrice = Console.ReadLine();

            match = regex.Match(customerProductCountPrice);

            while (customerProductCountPrice != "end of shift")
            {
                match = regex.Match(customerProductCountPrice);

                if (match.Success)
                {
                    string customer = match.Groups[1].Value;
                    string product = match.Groups[2].Value;
                    int count = int.Parse(match.Groups[3].Value);
                    decimal price = decimal.Parse(match.Groups[4].Value);

                    Bar bar = new Bar(customer, product, count, price);
                    income.Add(bar);

                }

                customerProductCountPrice = Console.ReadLine();
            }

            decimal total = 0;

            foreach (var item in income)
            {
                total += item.Count * item.Price;
                Console.WriteLine($"{item.Customer}: {item.Product} - {item.Price * item.Count:f2}");
            }
            Console.WriteLine($"Total income: {total:f2}");
        }
    }
}
