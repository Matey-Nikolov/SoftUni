﻿namespace ZipAndExtract
{
    using System;
    using System.IO.Compression;

    public class ZipAndExtract
    {
        static void Main()
        {
            // ..\..\..\File
            string inputFilePath = Console.ReadLine();

            // ..\..\..\archive.zip
            string zipArchiveFilePath = Console.ReadLine();

            ZipFileToArchive(inputFilePath, zipArchiveFilePath);

            // ..\..\..\archive.zip
            zipArchiveFilePath = Console.ReadLine();

            // extracted.png
            string fileName = Console.ReadLine();

            // ..\..\..\
            string outputFilePath = @"..\..\..\";

            ExtractFileFromArchive(zipArchiveFilePath, fileName, outputFilePath);

        }

        public static void ZipFileToArchive(string inputFilePath, string zipArchiveFilePath)
        {
            ZipFile.CreateFromDirectory(inputFilePath, zipArchiveFilePath);
        }
        
        public static void ExtractFileFromArchive(string zipArchiveFilePath, string fileName, string outputFilePath)
        {
            outputFilePath += fileName;

            ZipFile.ExtractToDirectory(zipArchiveFilePath, outputFilePath);
        }
    }
}