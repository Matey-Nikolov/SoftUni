﻿namespace CopyBinaryFile
{
    using System;
    using System.IO;

    public class CopyBinaryFile
    {
        static void Main()
        {
            // https://www.youtube.com/watch?v=eWRoeKygisU&ab_channel=C%C3%B3digoLogo
            string inputFilePath = @"..\..\..\Files\copyMe.png";
            string outputFilePath = @"..\..\..\Files\copyMe-copy.png";

            CopyFile(inputFilePath, outputFilePath);
        }

        public static void CopyFile(string inputFilePath, string outputFilePath)
        {
            using (FileStream streamRead = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read))
            {
                using (FileStream streamWrite = new FileStream(outputFilePath, FileMode.Create, FileAccess.Write))
                {
                    int bytesRead = 0;

                    byte[] buffer = new byte[4096];

                    while ((bytesRead = streamRead.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        streamWrite.Write(buffer, 0, bytesRead);
                    }
                }
            }
        }
    }
}