﻿namespace LineNumbers
{
    using System;
    using System.IO;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\Files\text.txt";
            string outputFilePath = @"..\..\..\Files\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] lineText = File.ReadAllLines(inputFilePath);
            string[] lineOutputText = new string[lineText.Length];

            int countLetters = 0;
            int countSpecialSymbol = 0;

            char[] charSpecial= new char[] { '-', ',', '.', '!', '?', '\''};

            for (int i = 0; i < lineText.Length; i++)
            {
                foreach (var item in lineText[i])
                {
                    int countOneOrZero = 0;

                    for (int j = 0; j < charSpecial.Length; j++)
                    {
                        if (item == charSpecial[j])
                        {
                            countSpecialSymbol++;
                            countOneOrZero++;
                        }
                    }

                    if (item != ' ' && countOneOrZero == 0)
                    {
                        countLetters++;
                    }
                }


                string output = $"Line {i + 1}: {lineText[i]} ({countLetters})({countSpecialSymbol})";
                lineOutputText[i] = output;

                File.WriteAllLines(outputFilePath, lineOutputText);

                countLetters = 0;
                countSpecialSymbol = 0;
            }     
        }
    }
}