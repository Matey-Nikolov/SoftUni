﻿namespace DirectoryTraversal
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class DirectoryTraversal
    {
        public static Dictionary<string, Dictionary<string, double>> directorySortFile = new Dictionary<string, Dictionary<string, double>>();

        static void Main()
        {
            string inputFolderPath = @"..\..\..\.";

            TraverseDirectory(inputFolderPath);
        }

        public static string TraverseDirectory(string inputFolderPath)
        {
            string[] fileDir = Directory.GetFiles(inputFolderPath);
            
            string reportFileName = @"C:\Users\matey\OneDrive\Desktop\report.txt";

            foreach (var item in fileDir)
            {
                WriteReportToDesktop(item, reportFileName);
            }

            return null;
        }

        public static void WriteReportToDesktop(string textContent, string reportFileName)
        {
            FileInfo itemInfo = new FileInfo(textContent);

            string extension = itemInfo.Extension;
            string name = itemInfo.Name;
            double sizeFile = itemInfo.Length;


            if (!directorySortFile.ContainsKey(itemInfo.Extension))
            {
                Dictionary<string, double> nameFileAndSize = new Dictionary<string, double>();
                nameFileAndSize.Add(name, sizeFile);
                directorySortFile.Add(extension, nameFileAndSize);
            }
            else
            {
                directorySortFile[extension].Add(name, sizeFile);
            }

            using (StreamWriter writer = new StreamWriter(reportFileName))
            {
                foreach (var fileItem in directorySortFile.OrderBy(x => x.Key))
                {
                    writer.WriteLine(fileItem.Key);

                    foreach (var getItemNameAndSiza in fileItem.Value.OrderByDescending(x => x.Value))
                    {
                        writer.WriteLine($"--{getItemNameAndSiza.Key} - {getItemNameAndSiza.Value / 1024:f3}kb");
                    }
                }
            }
        }
    }
}
