﻿namespace EvenLines
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class EvenLines
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            Console.WriteLine(ProcessLines(inputFilePath));
        }

        public static string ProcessLines(string inputFilePath)
        {
            string[] reverseString;
            int index = 0;
            StringBuilder sb = new StringBuilder();

            using (StreamReader reader = new StreamReader(inputFilePath))
            {
                string lineText = reader.ReadLine();

                string[] lineTextArry = lineText.Split(" "); // reader.ReadLine().lineText.Split(" ");
                reverseString = new string[lineTextArry.Length];

                for (int i = lineTextArry.Length - 1; i >= 0; i--)
                {
                    reverseString[index] += lineTextArry[i] + " ";
                    index++;
                }

                int count = 0;
                char[] charReplace = new char[] { '-', ',', '.', '!', '?' };

                while (lineText != null)
                {
                    if (index == 0)
                    {
                        lineTextArry = lineText.Split(" "); // reader.ReadLine().lineText.Split(" ");
                        reverseString = new string[lineTextArry.Length];

                        for (int i = lineTextArry.Length - 1; i >= 0; i--)
                        {
                            reverseString[index] += lineTextArry[i] + " ";
                            index++;
                        }
                    }


                    if (count % 2 == 0)
                    {
                        foreach (var item in charReplace)
                        {
                            for (int i = 0; i < reverseString.Length; i++)
                            {
                                if (reverseString[i].Contains(item))
                                {
                                    reverseString[i] = reverseString[i].Replace(item, '@');
                                }
                            }
                        }

                        foreach (var item in reverseString)
                        {
                            sb.Append(item);
                        }
                        sb.Append('\n');
                    }

                    count++;
                    index = 0;
                    lineText = reader.ReadLine();
                }
            }



            return sb.ToString();
        }
    }
}