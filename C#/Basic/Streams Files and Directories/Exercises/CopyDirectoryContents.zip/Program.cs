﻿namespace CopyDirectory
{
    using System;
    using System.IO;

    public class CopyDirectory
    {
        static void Main()
        {
            //https://www.youtube.com/watch?v=9mUuJIKq40M&ab_channel=IAmTimCorey
            
            //..\..\..\Files\Test1
            string inputPath = Console.ReadLine();
            //..\..\..\Files\
            string outputPath = Console.ReadLine();

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            string[] files = Directory.GetFiles(inputPath);
            //string destinationFolder = outputPath;

            foreach (var file in files)
            {
                File.Copy(file, $"{outputPath}{Path.GetFileName(file)}", false);
            }
        }
    }
}
