﻿namespace ExtractBytes
{
    using System.IO;

    public class ExtractBytes
    {
        static void Main()
        {
            string binaryFilePath = @"..\..\..\Files\example.png";
            string bytesFilePath = @"..\..\..\Files\bytes.txt";
            string outputPath = @"..\..\..\Files\output.txt";


            ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
        }

        public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
        {
            byte[] fileBytesRead = File.ReadAllBytes(binaryFilePath);
            
            using (StreamReader reader = new StreamReader(bytesFilePath))
            {
                string line = reader.ReadLine();

                using (StreamWriter writer = new StreamWriter(outputPath))
                {
                    while (line  != null)
                    {
                        foreach (var item in fileBytesRead)
                        {
                            if (line.Contains(item.ToString()))
                            {
                                writer.WriteLine(item.ToString());
                            }
                        }

                        line = reader.ReadLine();
                    }
                }
            }


        }
    }
}