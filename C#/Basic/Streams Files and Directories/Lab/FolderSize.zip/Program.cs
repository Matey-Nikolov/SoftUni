﻿namespace FolderSize
{
    using System;
    using System.IO;

    public class FolderSize
    {
        static void Main()
        {
            string folderPath = @"..\..\..\TestFolder";
            string outputFilePath = @"..\..\..\output.txt";

            GetFolderSize(folderPath, outputFilePath);
        }

        public static void GetFolderSize(string folderPath, string outputFilePath)
        {
            double sum = 0;

            DirectoryInfo directory = new DirectoryInfo(folderPath);
            FileInfo[] infos = directory.GetFiles("*", SearchOption.AllDirectories);

            foreach (FileInfo file in infos)
            {
                sum += file.Length;
            }

            sum = sum / 1024;

            File.WriteAllText(outputFilePath, sum.ToString() + " KB");
        }
    }
}