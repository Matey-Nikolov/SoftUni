﻿namespace WordCount
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class WordCount
    {
        static void Main()
        {
            string wordsFilePath = @"..\..\..\Files\words.txt";
            string textFilePath = @"..\..\..\Files\text.txt";
            string outputFilePath = @"..\..\..\Files\output.txt";


            CalculateWordCounts(wordsFilePath, textFilePath, outputFilePath);
        }

        public static void CalculateWordCounts(string wordsFilePath, string textFilePath, string outputFilePath)
        {
            Dictionary<string, int> wordAndCount = new Dictionary<string, int>();

            using (StreamReader reader = new StreamReader(textFilePath))
            {
                string line = reader.ReadLine();

                using (StreamReader readerWord = new StreamReader(wordsFilePath))
                {
                    string[] word = readerWord.ReadLine()
                        .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                    using (StreamWriter writer = new StreamWriter(outputFilePath))
                    {
                        int count = 0;

                        while (line != null)
                        {
                                foreach (var wordItem in word)
                                {
                                    if (line.ToLower().Contains(wordItem))
                                    {
                                        if (!wordAndCount.ContainsKey(wordItem))
                                        {
                                            wordAndCount.Add(wordItem, 0);
                                        }
                                        
                                        wordAndCount[wordItem]++;
                                    }

                                }

                            line = reader.ReadLine();
                         //   word = readerWord.ReadLine()
                          //      .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                        }

                        foreach (var item in wordAndCount.OrderByDescending(x => x.Value))
                        {
                            writer.WriteLine($"{item.Key} - {item.Value}");
                        }
                    }
                }
            }
        }
    }
}