﻿namespace MergeFiles
{

    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class MergeFiles
    {
        static void Main()
        {
            string firstInputFilePath = @"..\..\..\Files\input1.txt";
            string secondInputFilePath = @"..\..\..\Files\input2.txt";
            string outputFilePath = @"..\..\..\Files\output.txt";

            MergeTextFiles(firstInputFilePath, secondInputFilePath, outputFilePath);
        }

        public static void MergeTextFiles(string firstInputFilePath, string secondInputFilePath, string outputFilePath)
        {
            List<int> numbers = new List<int>();

            using (StreamReader readerInputOne = new StreamReader(firstInputFilePath))
            {
                string line1 = readerInputOne.ReadLine();

                using (StreamReader readerInputTwo = new StreamReader(secondInputFilePath))
                {
                    string line2 = readerInputTwo.ReadLine();


                    using (StreamWriter writer = new StreamWriter(outputFilePath))
                    {
                        while (line1 != null || line2 != null)
                        {

                            if (line1 != null)
                            {
                                int numberOne = int.Parse(line1);
                                numbers.Add(numberOne);
                            }
                           
                            if(line2 != null)
                            {
                                int numberTwo = int.Parse(line2);
                                numbers.Add(numberTwo);
                            }



                            line1 = readerInputOne.ReadLine();
                            line2 = readerInputTwo.ReadLine();
                        }

                        foreach (var item in numbers.OrderBy(x => x))
                        {
                            writer.WriteLine(item);
                        }
                    }
                }
            }
        }
    }
}