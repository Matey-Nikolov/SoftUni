﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercises_Iterators_and_Comparators_2
{
    public class Program
    {
        static void Main()
        {
            string[] create = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            ListyIterator<string> items = new ListyIterator<string>(create.Skip(1).ToArray());

            string movePrintHasNextEND = Console.ReadLine();

            while (movePrintHasNextEND != "END")
            {
                switch (movePrintHasNextEND)
                {
                    case "Move":
                        Console.WriteLine(items.Move());
                        break;
                    case "HasNext":
                        Console.WriteLine(items.HasNext());
                        break;
                    case "Print":
                            items.Print();
                        break;
                    // Add PrintAll - 6. Collection
                    case "PrintAll":
                        items.PrintAll();
                        break;
                }

                movePrintHasNextEND = Console.ReadLine();
            }
        }
    }
}