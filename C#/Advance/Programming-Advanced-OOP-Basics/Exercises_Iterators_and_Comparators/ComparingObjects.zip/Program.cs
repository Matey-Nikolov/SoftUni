﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Comparing_Objects
{
    public class Program
    {
        static void Main()
        {
            string[] input = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            List<Person> people = new List<Person>();

            while (input[0] != "END")
            {
                string name = input[0];
                int age = int.Parse(input[1]);
                string town = input[2];

                var person = new Person()
                {
                    Name = name,
                    Age = age,
                    Town = town
                };

                people.Add(person);

                input = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            }

            int n = int.Parse(Console.ReadLine());

            Person person1 = people[n - 1];

            int count = 0;
            for (int i = 0; i < people.Count; i++)
            {
                if (people[i].CompareTo(person1) == 0)
                {
                    count++;
                }
            }

            if (count > 1)
            {
                Console.WriteLine($"{count} {people.Count - count} {people.Count}");
            }
            else
            {
                Console.WriteLine($"No matches");
            }
        }
    }
}
