﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Exercises_Iterators_and_Comparators_2
{
    public class ListyIterator<T> : IEnumerable<T>
    {
        private List<T> items;

    //    public int Count { get; set; }

        private int index = 0;

        public ListyIterator(List<T> unputItems)
        {
            items = unputItems;
        }

        public bool Move()
        {
            if (index <= items.Count - 1)
            {
                index++;
                return true;
            }

            return false;
        }

        public bool HasNext()
        {
            if (index < items.Count - 1)
            {
                return true;
            }

            return false;
        }

        public void Print()
        {
            // ???
            if (items.Count == 0)
            {
                throw new Exception("Invalid Operation!");
            }
            else
                Console.WriteLine(items[index]);
        }

        public void PrintAll()
        {
            foreach (var item in items)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < items.Count; i++)
            {
                yield return items[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}