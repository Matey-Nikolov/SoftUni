﻿using System;
using System.Collections.Generic;

namespace Exercises_Iterators_and_Comparators_2
{
    public class Program
    {
        static void Main()
        {
            ListyIterator<string> items = null;

            string[] create = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            List<string> createList = new List<string>();

            for (int i = 1; i < create.Length; i++)
                createList.Add(create[i]);

            if (createList.Count == 0)
            {
                items = new ListyIterator<string>(createList);
            }
            else
            {
                items = new ListyIterator<string>(createList);
            }

            string movePrintHasNextEND = Console.ReadLine();

            while (movePrintHasNextEND != "END")
            {
                switch (movePrintHasNextEND)
                {
                    case "Move":
                        Console.WriteLine(items.Move());
                        break;
                    case "HasNext":
                        Console.WriteLine(items.HasNext());
                        break;
                    case "Print":
                            items.Print();
                        break;
                    // Add PrintAll - 6. Collection
                    case "PrintAll":
                        items.PrintAll();
                        break;
                }

                movePrintHasNextEND = Console.ReadLine();
            }
        }
    }
}