﻿namespace ImplementCustomStack
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class CustomStack<T>
    {
        private int InitialCapacity = 4;

        private T[] items;
        private int count;

        public CustomStack()
        {
            count = 0;
            items = new T[InitialCapacity];
        }

        public int Count { get => count; set => count = value; }
    
        public void Push(T item)
        {
            if (count >= items.Length)
            {
                Grow();
            }

            items[count] = item;
            count++;
        }

        public T Peek()
        {
            if (count == 0)
            {
                throw new InvalidOperationException("The stack is empty");
            }

            T lastItem = items[count - 1];
            return lastItem;
        }

        public T Pop()
        {
            if (count == 0)
            {
                throw new InvalidOperationException("The stack is empty");
            }

            T lastElement = items[count - 1];

            items[count - 1] = default(T);
            count--;

            return lastElement;
        }

        public void ForEach(Action<T> action)
        {
            for (int i = 0; i < count; i++)
            {
                action(items[i]);
            }
        }

        private void Grow()
        {
            var newArray = new T[items.Length * 2];
            Array.Copy(items, newArray, newArray.Length);
            items = newArray;
        }
    }
}