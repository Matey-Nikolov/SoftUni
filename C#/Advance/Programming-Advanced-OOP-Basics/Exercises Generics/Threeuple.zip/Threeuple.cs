﻿namespace Threeuple
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Threeuple<TItem1, TItem2, TItem3>
    {
        public TItem1 item1 { get; set; }
        public TItem2 item2 { get; set; }
        public TItem3 item3 { get; set; }

        public Threeuple(TItem1 name, TItem2 addressLitersBeerAccountBalance, TItem3 townDrunkOrNotOrBankName)
        {
            item1 = name;
            item2 = addressLitersBeerAccountBalance;
            item3 = townDrunkOrNotOrBankName;
        }
    }
}