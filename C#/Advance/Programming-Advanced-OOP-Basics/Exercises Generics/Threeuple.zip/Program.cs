﻿namespace Threeuple
{
    using System;

    public class Program
    {
        static void Main()
        {
            string[] firstNameLastNameAdressTown = Console.ReadLine()
                                                      .Split(" ");

            string name = firstNameLastNameAdressTown[0] + " " + firstNameLastNameAdressTown[1];
            string adress = firstNameLastNameAdressTown[2];
            string town = "";

            if (firstNameLastNameAdressTown.Length != 4)
            {
                 town = firstNameLastNameAdressTown[3] + " " + firstNameLastNameAdressTown[4];
            }
            else
            {
                town = firstNameLastNameAdressTown[3];
            }

            Threeuple<string, string, string> personAndAdressTown = new Threeuple<string, string, string>
                (name, adress, town);

            Console.WriteLine($"{personAndAdressTown.item1} -> {personAndAdressTown.item2} -> {personAndAdressTown.item3}");

            string[] nameLitersOfBeerDrunkOrNot = Console.ReadLine()
                              .Split(" ");

            name = nameLitersOfBeerDrunkOrNot[0];
            int litersOfBeer = int.Parse(nameLitersOfBeerDrunkOrNot[1]);
            string drunkOrNot = nameLitersOfBeerDrunkOrNot[2];
            bool trueFalse2 = false;

            if (drunkOrNot == "drunk")
            {
                trueFalse2 = true;
            }

            Threeuple<string, int, bool> NameBeerDrunkNot = new Threeuple<string, int, bool>
                (name, litersOfBeer, trueFalse2);

            Console.WriteLine($"{NameBeerDrunkNot.item1} -> {NameBeerDrunkNot.item2} -> {NameBeerDrunkNot.item3}");

            string[] nameAccountBalanceBankName = Console.ReadLine()
                               .Split(" ");

            name = nameAccountBalanceBankName[0];
            double accountBalance = double.Parse(nameAccountBalanceBankName[1]);
            string bankName = nameAccountBalanceBankName[2];

            Threeuple<string, double, string> NameAccountBankName = new Threeuple<string, double, string>
                (name, accountBalance, bankName);


            Console.WriteLine($"{NameAccountBankName.item1} -> {NameAccountBankName.item2} -> {NameAccountBankName.item3}");

        }
    }
}