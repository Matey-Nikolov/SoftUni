﻿namespace ImplementLinkedList
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Node<T>
    {
        public Node(T element, Node<T> next = null)
        {
            Element = element;
            Next = next;
        }

        public T Element { get; set; }

        public Node<T> Next { get; set; }
    }
}