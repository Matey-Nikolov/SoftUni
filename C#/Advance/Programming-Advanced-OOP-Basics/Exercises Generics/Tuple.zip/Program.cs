﻿namespace Exercises_Generics
{
    using System;

    public class Program
    {
        static void Main()
        {
            
            string[] firstNameLastNameAdress = Console.ReadLine()
                                                      .Split(" ");

            string name = firstNameLastNameAdress[0] + " " + firstNameLastNameAdress[1];
            string adress = firstNameLastNameAdress[2];

            Tuple<string, string> personAndAdress = new Tuple<string, string>
                (name,adress);

            Console.WriteLine($"{personAndAdress.item1} -> {personAndAdress.item2}");

            string[] nameLitersOfBeer = Console.ReadLine()
                                          .Split(" ");

            name = nameLitersOfBeer[0];
            int litersOfBeer = int.Parse(nameLitersOfBeer[1]);

            Tuple<string, int> NameBeer = new Tuple<string, int>
                (name, litersOfBeer);

             Console.WriteLine($"{NameBeer.item1} -> {NameBeer.item2}");

            string[] IntDouble = Console.ReadLine()
                                           .Split(" ");

            int number = int.Parse(IntDouble[0]);
            double numDouble = double.Parse(IntDouble[1]);

            Tuple<int, double> numberDoubleNum = new Tuple<int, double>
                (number, numDouble);

            Console.WriteLine($"{numberDoubleNum.item1} -> {numberDoubleNum.item2}");
        }
    }
}