﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises_Generics
{
    public class Tuple<TItem, TItem2>
    {
        public TItem item1 { get; set; }
        public TItem2 item2 { get; set; }

        public Tuple(TItem nameOrInt, TItem2 adressOrLiter)
        {
            item1 = nameOrInt;
            item2 = adressOrLiter;
        }

    }
}