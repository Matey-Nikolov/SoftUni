﻿namespace CarManufacturer
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        static void Main()
        {
            List<Tire[]> tires = new List<Tire[]>();
            List<Engine> engines = new List<Engine>();
            List<Car> cars = new List<Car>();

            string input = "";
            while ((input = Console.ReadLine()) != "No more tires")
            {
                // ТОВА НЕЩО НЕ РАБОТИ
                /*
                string[] tiresInfo = input.Split();
                List<Tire> currentTires = new List<Tire>();
                for (int i = 0; i < tiresInfo.Length; i += 2)
                {
                    var currentTire = new Tire(int.Parse(tiresInfo[i]), double.Parse(tiresInfo[i + 1]));
                    currentTires[i] = currentTire;
                }
                tires.Add(currentTires.ToArray());
                */
                string[] tiresInfo = input.Split();
                List<Tire> currentTires = new List<Tire>();
                

                for (int i = 0; i < tiresInfo.Length; i += 2)
                {
                    int year = int.Parse(tiresInfo[i]);
                    double pressure = double.Parse(tiresInfo[i + 1]);
                    Tire tire = new Tire(year, pressure);
                    currentTires.Add(tire);
                }

                tires.Add(currentTires.ToArray());
            }

            while ((input = Console.ReadLine()) != "Engines done")
            {
                string[] engineInfo = input.Split();
                var currentEngine = new Engine(int.Parse(engineInfo[0]), double.Parse(engineInfo[1]));
                engines.Add(currentEngine);
            }

            while ((input = Console.ReadLine()) != "Show special")
            {
                string[] carInfo = input.Split();
                Engine engine = engines[int.Parse(carInfo[5])];
                Tire[] currentTires = tires[int.Parse(carInfo[6])];
                Car currentCar = new Car(carInfo[0], carInfo[1], int.Parse(carInfo[2]), double.Parse(carInfo[3]), double.Parse(carInfo[4]), engine, currentTires);
                cars.Add(currentCar);
            }

            cars = cars.Where(x => x.Year >= 2017).ToList();
            cars = cars.Where(x => x.Engine.HorsePower > 330).ToList();
            cars = cars.Where(x => x.Tires.Sum(x => x.Pressure) <= 10 && x.Tires.Sum(x => x.Pressure) >= 9).ToList();

            

            foreach (var item in cars)
            {
                item.Drive(20);

                Console.WriteLine($"Make: {item.Make}");
                Console.WriteLine($"Model: {item.Model}");
                Console.WriteLine($"Year: {item.Year}");
                Console.WriteLine($"HorsePowers: {item.Engine.HorsePower}");
                Console.WriteLine($"FuelQuantity: {item.FuelQuantity}");
            }
        }
    }
}
