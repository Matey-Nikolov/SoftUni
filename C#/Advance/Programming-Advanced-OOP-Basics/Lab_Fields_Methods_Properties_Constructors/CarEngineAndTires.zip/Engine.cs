﻿namespace CarManufacturer
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Engine
    {
        private double cubicCapacity;
        private int horsePower;

        public double CubicCapacity
        {
            get { return cubicCapacity; }
            set { cubicCapacity = value; }
        }

        public int HorsePower
        {
            get { return horsePower; }
            set { horsePower = value; }
        }

        public Engine(int horsePower, double cubicCapacity)
        {
            HorsePower = horsePower;
            CubicCapacity = cubicCapacity;
        }

        //public int HorsePower1 { get; set; }
       // public double CubicCapacity1 { get; set; }


    }
}